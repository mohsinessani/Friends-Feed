<?php  
	include("includes/header.php");

	$message_obj=new Message($con,$userLoggedIn);

	if(isset($_GET['u']))
		$user_to=$_GET['u'];
	else
	{
		$user_to=$message_obj->getMostRecentUser();
		if($user_to == false)
			$user_to='new';
	}

	if($user_to != "new")
		$user_to_obj=new User($con,$user_to);

	if(isset($_POST['post_message']))
	{
		if(isset($_POST['message_body']))
		{
			$body=mysqli_real_escape_string($con,$_POST['message_body']);
			$date=date("Y-m-d H:i:s"); //Current date and Time
			$message_obj->sendMessage($user_to,$body,$date);
		}
	}
?>
	<link rel="stylesheet"  href="indestyle.css">
	<!-- for on scroll animations -->
      <link rel="stylesheet" href="animate.css">
      <script src="wow.min.js"></script>
	  
	<div class="user_details column animated slideInDown" id="details">
		<a href="<?php echo $userLoggedIn; ?>"> <img src="<?php echo $user['profile_pic']; ?>"></a>
		<div class="user_details_left_right">
		<div class="namedetails" id="messdetails">
		<a href="<?php echo $userLoggedIn; ?>">
		<?php echo $user['first_name']." ".$user['last_name']; ?>
		</a>
		</div>
		<br>
		
		 <?php #echo "Posts: ".$user['num_post']."<br>"; 
			 # echo "Likes: ".$user['num_likes']; ?> 
		
	</div>
</div>
	
	<div class="main_column column animated slideInRight" id="message_column">
		<?php  
			if($user_to != "new")
			{
				echo "<h4>You and <a href='$user_to'>".$user_to_obj->getFirstAndLastName()."</a></h4><hr><br>";
				echo "<div class='loaded_messages' id='scroll_message'>";
				echo $message_obj->getMessages($user_to);
				echo "</div>";
			}
			else
			{
				echo "<h4>New Message</h4>";
			}
		?>
		<div class="message_post">
			<form action="" method="POST">
				<?php  
					if($user_to == "new")
					{
						echo "Select the friend would you like to message <br><br>";
?> 
						To: <input type='text' onkeyup='getUsers(this.value, "<?php echo $userLoggedIn; ?>")' name='q' placeholder=' Enter Name...' autocomplete='off' id='seach_text_input'>
<?php
						echo "<div class='results'></div>";
					}
					else
					{
						echo "<textarea name='message_body' id='message_textarea' placeholder='Write your message...'></textarea>";
						echo "<input type='submit' name='post_message' class='info' id='message_submit' value='Send'>";
					}
				?>
			</form>
		</div>
	</div>
		<script>
			var div=document.getElementById("scroll_message");
			div.scrollTop=div.scrollHeight;
		</script>

		<div class="user_details column animated slideInLeft" id="conversations">
			<h4>Conversations</h4>
			<div class="loaded_conversation">
				<?php echo $message_obj->getCanvas(); ?>
			</div>
			<br>
			<a href="messages.php?u=new">New Message</a>
		</div>